<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Manufacturing\\Providers\\ManufacturingServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Manufacturing\\Providers\\ManufacturingServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);