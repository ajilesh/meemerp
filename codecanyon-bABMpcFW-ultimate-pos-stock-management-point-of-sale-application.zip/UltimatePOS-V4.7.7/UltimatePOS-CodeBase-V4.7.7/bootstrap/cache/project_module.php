<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Project\\Providers\\ProjectServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Project\\Providers\\ProjectServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);