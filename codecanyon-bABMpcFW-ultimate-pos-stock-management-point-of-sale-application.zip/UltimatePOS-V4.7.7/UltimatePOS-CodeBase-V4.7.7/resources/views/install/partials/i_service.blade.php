<div class="col-md-12">
	<hr/>
	<h3 class="text-danger">Install/Update Service</h3>
	<p class="text-center">
		<a href="https://ultimatefosters.com/product/installation-update-service/" target="_blank" class="btn btn-warning"><i class="fas fa-cogs"></i> Take Installation/update Service</a>
	</p>
	<hr/>
</div>